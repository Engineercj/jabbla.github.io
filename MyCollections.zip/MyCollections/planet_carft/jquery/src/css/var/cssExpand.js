define( function() {
	return [ "Top", "Right", "Bottom", "Left" ];
} );
